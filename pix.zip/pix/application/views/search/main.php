 <?php 

// $search = "tom";
// $search = str_replace(' ', '+', $search);
// $total_round = 1;

// $base = 1 ;$begin = 01; $count = 28;
// for ($ti=0; $ti < $total_round ; $ti++) { 

// 	$urlContent = file_get_contents('https://www.bing.com/images/search?q=+'.$search.'+&first='.$begin.'&count='.$count.'&FORM=HDRSC2');

// 		$dom = new DOMDocument();
// 		@$dom->loadHTML($urlContent);
// 		$xpath = new DOMXPath($dom);
// 		$hrefs = $xpath->evaluate("/html/body//a");

// 		for($i = 0; $i < $hrefs->length; $i++){
// 		    $href = $hrefs->item($i);
// 		    $url = $href->getAttribute('href');
// 		    $url = filter_var($url, FILTER_SANITIZE_URL);
// 		    if(!filter_var($url, FILTER_VALIDATE_URL) === false){
// 		        $check = substr($url, -4);
// 		        if($check == '.jpg' || $check == '.png' || $check == '.gif' || $check == 'jpeg' ){
// 		       		//echo '<a href="'.$url.'">'.$url.'</a><br />';
// 		       		$image[$base][$i] = $url;
// 		        }
// 		    }
// 		}
// 	$begin = $begin + 28; $count = $count + 28; $base = $base + 1;
// }

// echo "<pre>";
// 		$new_image=array();
// 		for($i=1;$i<=count($image);$i++){
// 			$new_image=array_merge($new_image,$image[$i]);
// 		}
// echo "</pre>";

?> 


<div class="container">
        <div class="row">
        <div class="gallery col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <h1 class="gallery-title">zipipiz</h1>
        </div>

         <div align="center">
        <div class="col-md-6">
         	<div class="form-group">
                <div class="icon-addon addon-lg">
                    <input type="text" placeholder="Search" class="form-control" id="Search" value="">
                    <!-- <label for="email" class="glyphicon glyphicon-search" rel="tooltip" title="email"></label> -->
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="form-group">
                <div class="icon-addon addon-lg">
                <button id="result">SEARCH</button>
                <?php echo base_url(); ?>
                </div>
            </div>
        </div>


        </div> 


        <div id="#result_image"></div>
       

<!-- <?php 
if(isset($new_image)){
foreach ($new_image as $key => $value)
{
?>
<div class="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 filter hdpe" style="width:  100px; height:  100px;">
    <img src="<?php echo $value; ?>" class="img-responsive">
</div>
<?php } } ?> -->


        </div>
    </div>



<style>
.gallery-title
{
    font-size: 36px;
    color: #42B32F;
    text-align: center;
    font-weight: 500;
    margin-bottom: 70px;
}
.gallery-title:after {
    content: "";
    position: absolute;
    width: 7.5%;
    left: 46.5%;
    height: 45px;
    border-bottom: 1px solid #5e5e5e;
}
.filter-button
{
    font-size: 18px;
    border: 1px solid #42B32F;
    border-radius: 5px;
    text-align: center;
    color: #42B32F;
    margin-bottom: 30px;

}
.filter-button:hover
{
    font-size: 18px;
    border: 1px solid #42B32F;
    border-radius: 5px;
    text-align: center;
    color: #ffffff;
    background-color: #42B32F;

}
.btn-default:active .filter-button:active
{
    background-color: #42B32F;
    color: white;
}

.port-image
{
    width: 100%;
}

.gallery_product
{
    margin-bottom: 30px;
}




</style>


<script>
    $('#result').click(function(){
        $.ajax({
           type: "POST",
           url: "<?php echo base_url(); ?>Search/image_result",
           data: {search: $('#Search').val()},
            //datatype:'text',
           cache: true,
           async: false,
           success: function(data){
                document.getElementById('result_image').innerHTML = data;
            // alert(data);
            console.log(data[0]);
           }
         });
    });
     
</script>