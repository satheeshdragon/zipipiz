<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Search_model extends CI_Model {

public function search_result($search)
	{
	
		//$search = "tom";
		$search = str_replace(' ', '+', $search);
		$total_round = 1;

		$base = 1 ;$begin = 01; $count = 28;
		for ($ti=0; $ti < $total_round ; $ti++) { 

			$urlContent = file_get_contents('https://www.bing.com/images/search?q=+'.$search.'+&first='.$begin.'&count='.$count.'&FORM=HDRSC2');

				$dom = new DOMDocument();
				@$dom->loadHTML($urlContent);
				$xpath = new DOMXPath($dom);
				$hrefs = $xpath->evaluate("/html/body//a");

				for($i = 0; $i < $hrefs->length; $i++){
				    $href = $hrefs->item($i);
				    $url = $href->getAttribute('href');
				    $url = filter_var($url, FILTER_SANITIZE_URL);
				    if(!filter_var($url, FILTER_VALIDATE_URL) === false){
				        $check = substr($url, -4);
				        if($check == '.jpg' || $check == '.png' || $check == '.gif' || $check == 'jpeg' ){
				       		//echo '<a href="'.$url.'">'.$url.'</a><br />';
				       		$image[$base][$i] = $url;
				        }
				    }
				}
			$begin = $begin + 28; $count = $count + 28; $base = $base + 1;
		}

				$new_image=array();
				for($i=1;$i<=count($image);$i++){
					$new_image=array_merge($new_image,$image[$i]);
				}

if(isset($new_image)){
foreach ($new_image as $key => $value)
{
	$data = '<div class="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 filter hdpe" style="width:  100px; height:  100px;">
    <img src="'.$value.'" class="img-responsive">
</div>';
 } } 


		return $data;

	}	

}

/* End of file search_model.php */
/* Location: ./application/models/search_model.php */