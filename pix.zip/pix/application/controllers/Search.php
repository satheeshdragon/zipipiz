<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Search extends CI_Controller {

	public function __construct() {
        parent::__construct();
        // if ($this->session->userdata('is_logged_in') == '') {            
        //     redirect('login');
        //     session_destroy();
        // }
         $this->load->model('search_model');
    }

	public function index()
	{
		$template['page'] =	"search/main";
		$this->load->view('template',$template);
	}


    // Image Results

    public function image_result()
    {
        $image_name = $this->input->post('search');
        $search     = $this->search_model->search_result($image_name);

        //echo json_encode($search);
         print_r($search);
    }

}

/* End of file Search.php */
/* Location: ./application/controllers/Search.php */